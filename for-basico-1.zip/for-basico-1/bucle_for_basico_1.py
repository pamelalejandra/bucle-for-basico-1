#1. Basico
for i in range(151):
    print (i)
    
#2. Multiplos de cinco
for i in range(5,1001,5):
    print (i)

#3. Contar, a la manera del Dojo
for i in range(1,101):
    if i % 10 == 0:
        print ("Coding Dojo")
    elif i % 5 == 0:
        print ("Coding")
    else:
        print(i)

#4.Whoa. Es un gran idiota
resultado = 0
for i in range (1, 500001, 2):
    resultado += i
    print (resultado)
    #62.500.000.000

#5. Cuenta regresiva de a 4
for i in range (2018,0, -4):
    print (i)

#6. Contador flexible
lowNum = 3
highNum = 10
mult= 4
for n in range (lowNum, highNum):
    if n % mult == 0:
        print (n)